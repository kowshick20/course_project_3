import heapq
import math
from collections import defaultdict
from typing import List, Tuple, Any, Dict, Optional

from CityGraph import CityGraph


def safe_cost(costs, city_a, city_b, day):
    """
    Give the cost of travelling from city_a to city_b in a given day
    """
    entry = costs.get((city_a, city_b), {})
    if isinstance(entry, dict):
        return float(entry.get(day, float("inf")))
    return float("inf")


class Astar:
    def __init__(self, graph: CityGraph, coordinates, max_days: int = 30,
                 penalty_factor: float = 10, use_direction_penalty: bool = True):
        self.usa_map = graph  # complete USA Cities following EST
        self.max_days = graph.days  # Max available days of data
        self.penalty_factor = penalty_factor  # penalty of moving in wrong direction
        self.use_direction_penalty = use_direction_penalty
        self.pair_cache = {}
        self.coordinates = coordinates  # latitude and longitude coordinate of each city
        # Meta data JSON
        self.meta_data = {
            "daily": defaultdict(lambda: {"path": [], "distance": 0.0, "fuel": 0.0, "risk": 0.0, "edges": []}),
            "total": {"distance": 0.0, "fuel": 0.0, "risk": 0.0, "days_travelled": 0, "total_path": []}}

    dest_reach_day = 0

    def search(self, current: str, destination: str, start_day: int = 0) -> Optional[Dict[str, Any]]:
        """
        A* start algorithm
        :param current: current city
        :param destination: destination city
        :return: metadata JSON if when reached else empty
        """
        # reset
        self.meta_data = {
            "daily": defaultdict(lambda: {"path": [], "distance": 0.0, "fuel": 0.0, "risk": 0.0, "edges": []}),
            "total": {"distance": 0.0, "fuel": 0.0, "risk": 0.0, "days_travelled": 0, "total_path": []}}

        # priority q
        # h,g,current_city,days_taken, path
        open_pq: List[Tuple[float, float, str, int, List[str]]] = []
        starting_hur = 0.0  # initial h function

        heapq.heappush(open_pq, (starting_hur, 0.0, current, start_day, [current]))  # push start city into pq

        best_route = {}  # Best route to take on the given day

        # Until empty
        while open_pq:
            # pop first element
            hur, g, current, day, path = heapq.heappop(open_pq)
            if current == destination:  # reached destination
                self.meta_data["total"]["total_path"] = path  # path taken to reach destination
                self.meta_data["total"]["days_travelled"] = day  # days taken to reach the destination
                self.populate_meta_data(path, start_day)  # generate the meta_data

                return {
                    "path": path,
                    "cost": g,
                    "days_travelled": day,
                    "meta_data": self.meta_data
                }

            if day >= self.max_days:  # not able to complete travel within given days
                continue

            key = (current, day)
            # if we have a better day to travel this route? skip today
            if key in best_route and g > best_route[key] + 1e-9:
                continue
            best_route[key] = g  # best route for the day to travel

            # Cities reachable within today

            reachable = self.usa_map.reachable_within_day_min_cost(current, day)
            # print(reachable)
            for dest, info in reachable.items():
                if dest == current:
                    continue

                trans_cost = info["cost"]  # cost taken to reach
                first_hop = info["edges"][0] if info["edges"] else (current, dest)  # Paths to be taken
                next_city = first_hop[1]  # immediate next city
                # penalize if the movement is opposite to the goal direction
                # direction_penalty = self.direction_penalty(current, next_city, destination)
                h = self.heuristic(current, next_city, destination)  # get the heuristic data
                # total cost is the cost to travel and the direction penalty
            
                # new accumulated cost
                new_g = g + trans_cost  # g function is added with cost to reach
                new_day = day + 1  # next day
                # h = self.heuristic(dest, destination)
                new_f = new_g + h  # f=g+h
                # include the multi hop path in final path
                new_path = path + info["path"][1:]  # skip in initial node, which is the current node
                # check for better day
                key2 = (dest, new_day)
                if key2 in best_route and new_g >= best_route[key2] - 1e-9:
                    continue
                heapq.heappush(open_pq, (new_f, new_g, dest, new_day, new_path))  # push the element

        return None  # if goal cannot be reached

    def populate_meta_data(self, final_path, day):
        """
        Backtracks and reconstructs the travel details,
         always greedy, chooses the max distance to travel per day
         :param final_path: Local path of reaching city a to b
         :param day: Travel day
        """
        remaining_cities = list(final_path)  #cities to travel
        current_day = day #current day
        current_city = remaining_cities[0] #start city
        i = 1  #index of the next city in final_path
        total_travel_days = 0 #days travelled so far

        #Unitil visited all cities and have days left for travel
        while i < len(remaining_cities) and current_day < self.usa_map.days:

            #Cities reachable from here, on a given day
            reachable = self.usa_map.reachable_within_day_min_cost(current_city, current_day)

            #store the results
            best_prefix_len = 0
            best_dest = None
            best_metadata = None

            #Greedy aim for the max distance
            for j in range(i, len(remaining_cities)):
                possible_dest = remaining_cities[j] #possible destination

                if possible_dest in reachable:  #is it reachable today?
                    metadata = reachable[possible_dest]
                    prefix_nodes = metadata["path"]

                    #Travel to the farthest available
                    if prefix_nodes == remaining_cities[i - 1: j + 1]:
                        if (j - i + 1) > best_prefix_len:
                            best_prefix_len = j - i + 1
                            best_dest = possible_dest
                            best_metadata = metadata

            #fail-safe, no farthest? travel to next city
            if best_dest is None:
                next_city = remaining_cities[i]
                if next_city in reachable:
                    best_prefix_len = 1
                    best_dest = next_city
                    best_metadata = reachable[next_city]
                else:
                    break  # cannot travel today → stop

            #Record the travel for the day
            day_record = self.meta_data["daily"][current_day]
            day_record["path"] = best_metadata["path"]
            day_record["distance"] = best_metadata["distance"]
            day_record["fuel"] = 0.0
            day_record["risk"] = 0.0
            day_record["edges"] = []

            #Talk to the graph to get the fuel,distance details
            for (from_city, to_city) in best_metadata["edges"]:
                #get details from graph
                info = self.usa_map.get_edge_info(from_city, to_city, current_day)
                if info is None:
                    continue

                day_record["fuel"] += info["gallons"]
                day_record["risk"] += info["avg_weather"]
                total_travel_days += info['days']
                day_record["edges"].append({
                    "from": from_city, "to": to_city,
                    "distance": info["distance"],
                    "gallons": info["gallons"],
                    "avg_weather": info["avg_weather"],
                    "weight": info["weight"]
                })

                self.meta_data["total"]["distance"] += info["distance"]
                self.meta_data["total"]["fuel"] += info["gallons"]
                self.meta_data["total"]["risk"] += info["avg_weather"]

            #Continue the loop
            current_city = best_dest
            i += best_prefix_len
            current_day += 1

        self.meta_data["total"]["days_travelled"] = total_travel_days

    def compute_local_travel_cost(self, city_a: str, city_b: str):
        """
        Calculate the route cost for travelling from city-a to city-b for the period of 30 days
        :param city_a: start city
        :param city_b: end city
        :return: travel cost for 30 days
        """
        #if cost is already computed, return the same
        #DP approach
        key = (city_a, city_b)
        if key in self.pair_cache:
            return self.pair_cache[key]

        result_by_day = {}

        #all 30 days
        for start_day in range(self.max_days):
            #get the metadata and cost
            res = self.search(city_a, city_b, start_day=start_day)

            #if no path for day, no cost
            if res is None:
                result_by_day[start_day] = {
                    "path": [],
                    "cost": float("inf"),
                    "days_travelled": None,
                    "meta_data": None
                }
            else:
                result_by_day[start_day] = res
        #memoiize
        self.pair_cache[key] = result_by_day

        return result_by_day

    def build_cost_matrix(self, cities):
        """
        Build the cost matrix for travel one city to the other for the period of 30 days
        :param cities: List of cities needed to be visited
        :return: the cost matix
        """
        costs = {}  # cost
        #calculate the cost of each pair of the city
        for i, city_a in enumerate(cities):
            for city_b in cities[i + 1:]:
                #cost of city_A to City_b
                ab = self.compute_local_travel_cost(city_a, city_b)
                costs[(city_a, city_b)] = {
                    int(day): int(ab[day]["cost"]) if ab[day]["cost"] != float("inf") else 999
                    for day in ab
                }

                #cost of city_A to City_b, not A-B and B-A are not same
                ba = self.compute_local_travel_cost(city_b, city_a)
                costs[(city_b, city_a)] = {
                    int(day): int(ba[day]["cost"]) if ba[day]["cost"] != float("inf") else 999
                    for day in ba
                }

        #Cost for the same city is always 0
        for city in cities:
            costs[(city, city)] = {day: 0.0 for day in range(self.max_days)}

        return costs

    def execute_multiplicity(self, city_list):
        """
        Plan a multi-day travel route through a list of cities.

        Args:
            city_list (list): Ordered list of cities to travel through.

        Returns:
            dict: Contains ordered route, trips info, total distance, days, fuel,
                  daily itinerary, and the full path taken.
        """
        trips = []  # Info about travel between consecutive cities
        total_distance = 0.0
        total_days = 0
        total_fuel = 0.0
        current_day = 0  # Tracks the global day count
        final_path = []  # Complete path for all trips
        daily_schedule = []  # Day-wise itinerary

        for i in range(len(city_list) - 1):
            city_from = city_list[i]
            city_to = city_list[i + 1]

            # Compute pairwise travel info
            result = self.compute_local_travel_cost(city_from, city_to)

            # print('Cost for this trip:', result[current_day]['cost'])

            # If cities cannot be reached
            if result is None or result[current_day]["cost"] == float("inf"):
                trips.append({"from": city_from, "to": city_to})
                continue
            # Record the trip info

            trips.append({
                "from": city_from,
                "to": city_to,
                "cost": result[current_day]["cost"],
                "days_travelled": result[current_day]["days_travelled"],
                "path": result[current_day]["path"],
                "meta_data": result[current_day]["meta_data"]
            })

            # Process multi-day travel metadata if available
            meta = result[current_day]["meta_data"]
            if meta:
                for day_index, day_info in meta["daily"].items():
                    # print(current_day)
                    # print(meta["daily"].items())
                    daily_schedule.append({

                        "global_day": int(total_days),
                        "trip_from": city_from,
                        "trip_to": city_to,
                        "path": day_info["path"],
                        "distance": day_info["distance"],
                        "fuel": day_info["fuel"],
                        "edges": day_info["edges"]
                    })
                    total_distance += day_info["distance"]
                    total_fuel += day_info["fuel"]
                    total_days += 1

                # Update the current global day after this trip
                # print(meta["total"]["days_travelled"])
                current_day = meta["total"]["days_travelled"]
                # print(current_day)
            # Update the final full path
            if result[current_day]["path"]:
                if not final_path:
                    final_path.extend(result[current_day]["path"])
                else:
                    # Avoid repeating the last city of previous path
                    final_path.extend(result[current_day]["path"][1:])

        return {
            "ordered_route": city_list,
            "trip": trips,
            "total_distance": total_distance,
            "total_days": total_days,
            "total_fuel": total_fuel,
            "daily_route": daily_schedule,
            "final_path": final_path
        }

    def trip(self, initial_city_list):
        # needs at least two cities to travel
        if len(initial_city_list) < 2:
            return "need least two cities to travel"

        city_list = list(dict.fromkeys(initial_city_list))  # remove duplicates if any

        # fail-safe
        for city in city_list:
            if city not in self.usa_map.cities:
                return f"city {city} not found in map"
        # Take a initial guess and jump start the A*
        costs = self.build_cost_matrix(city_list)  # Pairwise costs
        #print('costmatrix', costs)  # input order is calculated
        initial_route = self.build_initial_route(city_list, costs)  # initial greedy path
        #print('initial', initial_route)
        improved_route = self.improve_path(initial_route, costs)  # optimize route
        #print('opti', improved_route)
        # both opt and final is same
        aggregated = self.execute_multiplicity(improved_route)
        aggregated["initial_route"] = initial_route
        aggregated["final_route"] = improved_route
        aggregated["pairwise_costs"] = costs
        #print(aggregated)
        return aggregated

    def heuristic(self, current: str, next_city: str, destination: str) -> float:
        """
        method to the h function of to next city towards dest city, says how many gas will be needed
        It penalizes to move in the opposite direction of dest
        """

        # get latitude and longitude coordinates of current, dest and next city
        coordinates_current_city = self.coordinates[current]
        coordinates_next_city = self.coordinates[next_city]
        coordinates_destination_city = self.coordinates[destination]

        if coordinates_current_city and coordinates_destination_city:
            dx = coordinates_destination_city[0] - coordinates_current_city[0]
            dy = coordinates_destination_city[1] - coordinates_current_city[1]

            straight_dist = math.hypot(dx, dy)  # get distance between current and destination
            base_h = straight_dist / self.usa_map.base_mpg  # estimated fuel needed to reach goal
        else:
            base_h = 0.0

        # direction penalty disabled
        if not self.use_direction_penalty:
            return base_h

        # coordinates not found
        if not coordinates_current_city or not coordinates_next_city or not coordinates_destination_city:
            return base_h

        vx = coordinates_destination_city[0] - coordinates_current_city[0]
        vy = coordinates_destination_city[1] - coordinates_current_city[1]
        ux = coordinates_next_city[0] - coordinates_current_city[0]
        uy = coordinates_next_city[1] - coordinates_current_city[1]

        theta = math.hypot(vx, vy) * math.hypot(ux, uy)
        # reached
        if theta == 0:
            return base_h

        cos_theta = (vx * ux + vy * uy) / theta  # cos angle tells the direction

        # towards dest
        if cos_theta >= 0:
            return base_h

        # opposite direction
        penalty = (-cos_theta) * self.penalty_factor * (straight_dist / self.usa_map.base_mpg)

        return base_h + penalty  # add penalty

    def get_travel_days(self, city_a, city_b, day):
        print(city_a, city_b, 0)
        info = self.usa_map.get_edge_info(city_a, city_b, 0)
        if info is None:
            return 0
        return info['days']

    def build_initial_route(self, cities, costs, max_days=30):
        """
        Initial route identifier using greed algo, that takes in the travel constraints
        :param cities: Cities to visit
        :param costs: Cost of travelling for the next 30 days
        :param max_days: Can travel for 30 day at max
        :return: the initial greedy route
        """
        print(costs)

        # pick the city with the least cost as the starting city
        best_city = min(cities, key=lambda c: sum(safe_cost(costs, c, o, 1) for o in cities if o != c))
        route = [best_city]
        unvisited = set(cities) - {best_city}

        current_day = 1  # starting on day 1

        # build the complete route
        while unvisited and current_day <= max_days:
            current_city = route[-1]

            # pick the next city that has the minimum cost as of today
            next_city = min(
                unvisited,
                key=lambda c: safe_cost(costs, current_city, c, current_day)
            )
            travel_cost = safe_cost(costs, current_city, next_city, current_day)
            travel_days = self.get_travel_days(current_city, next_city, current_day)
            # If infinite cost cannot travel there today so try tomorrow
            if travel_cost == float("inf"):
                current_day += 1
                if current_day > max_days:
                    break
                continue

            # Note the successfully travel location
            route.append(next_city)
            unvisited.remove(next_city)
            # Increment day
            current_day += travel_days

        return route

    def improve_path(self, route, costs, max_days=30, shots=200):
        """
        Improve the initial route using 2-opt method
        :param route: initial rote
        :param costs: cost matrix for 30 days
        :param max_days: we can travel for max

        :return: Improved route (if any)
        """

        def total_cost(path):
            current_day = 1
            total = 0.0
            for i in range(len(path) - 1):
                if current_day > max_days:
                    break
                total += safe_cost(costs, path[i], path[i + 1], current_day)
                current_day += self.get_travel_days(path[i], path[i + 1], current_day)
                current_day += 1
            return total

        best_path = route[:]
        best_cost = total_cost(best_path)
        n = len(route)  #lrngth
        improved = True  #is route improved?
        attempts = 0  #track of iterations

        while improved and attempts < shots:
            improved = False
            attempts += 1
            for i in range(1, n - 2):
                for j in range(i + 1, n - 2):
                    new_path = (best_path[:i] + best_path[i:j + 1][::-1] +
                                best_path[j + 1:])
                    new_cost = total_cost((new_path))
                    if new_cost < best_cost:
                        best_path = new_path
                        best_cost = new_cost
                        improved = True
                        break

                if improved:
                    break

        return best_path
