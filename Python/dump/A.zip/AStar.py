import heapq
import math
from collections import defaultdict
from typing import List, Tuple, Any, Dict, Optional

from numpy.f2py.crackfortran import sourcecodeform

from CityGraph import CityGraph


def build_initial_route(cities, costs):
    scores = []
    for city in cities:
        s = sum(costs.get((city, c), float('inf')) for c in cities if c != city)
        # s = sum(costs[(city,c)] for c in cities if c!=city)
        scores.append((s, city))
    scores.sort()
    start_city = scores[0][1]
    route = [start_city]
    unvisited = set(cities) - {start_city}  # unvisited city list

    while unvisited:
        prev_city = route[-1]
        next_city = min(unvisited, key=lambda x: costs.get((prev_city, x), float("inf")))
        route.append(next_city)  # take a move
        unvisited.remove(next_city)  # mark as visited

    return route


def improve_path(route, cost, shots=200):
    """
    Optimize the travel route by making  cost-effective, by interchanging the
    source and destination cities, if it reduces the cost
    :param route: initial path to travel all cities
    :param cost: initial cost
    :param shots: maximum iterations allowed
    :return: new path
    """

    def cost_between(current, dest):
        """
        Get cost between source and destination
        :param current: source city
        :param dest: destination city
        :return: cost between the two if missing key exception
        """
        # find cost between source and dest
        if (current, dest) in cost:
            return cost[(current, dest)]
        if (dest, current) in cost:
            return cost[(dest, current)]
        raise KeyError(f"No travel cost found between {current} and {dest}")

    def full_path_cost(path):
        """
        Cost of full path
        :param path: Path taken to travel
        """
        total_cost = 0.0
        for i in range(len(path) - 1):
            # cost between the city and the next required city
            total_cost += cost_between(path[i], path[i + 1])
        return total_cost

    best_path = route[:]
    best_cost = full_path_cost(best_path)  # total cost
    found_better_path = True
    attempt = 0
    n = len(route)

    while found_better_path and attempt < shots:
        found_better_path = False
        attempt += 1

        for start in range(1, n - 2):
            for des in range(start + 1, n - 1):
                # remove old path and connect new two cities
                before_starting = best_path[start - 1]
                start_city = best_path[start]
                end_city = best_path[des]
                after_end = best_path[des + 1]

                # old path to be removed
                old_cost = (
                        cost_between(before_starting, start_city) +
                        cost_between(end_city, after_end)
                )
                # new path to be added
                new_cost = (
                        cost_between(before_starting, end_city) +
                        cost_between(start_city, after_end)
                )

                cost_difference = new_cost - old_cost

                if cost_difference < 0:  # if cheaper
                    # flip path
                    new_path = (
                            best_path[:start] +
                            best_path[start:des + 1][::1] +
                            best_path[des + 1:]
                    )
                    # update path and cost
                    best_path = new_path
                    best_cost += cost_difference
                    found_better_path = True
                    break  # search again

            if found_better_path:
                break

        return best_path


class Astar:
    def __init__(self, graph: CityGraph, coordinates, max_days: int = 5,
                 penalty_factor: float = 10, use_direction_penalty: bool = True):
        self.usa_map = graph  # complete USA Cities following EST
        self.max_days = min(max_days, graph.days)  # Max available days of data
        self.penalty_factor = penalty_factor  # penalty of moving in wrong direction
        self.use_direction_penalty = use_direction_penalty
        self.pair_cache = {}
        self.coordinates = coordinates  # latitude and longitude coordinate of each city
        # Meta data JSON
        self.meta_data = {
            "daily": defaultdict(lambda: {"path": [], "distance": 0.0, "fuel": 0.0, "risk": 0.0, "edges": []}),
            "total": {"distance": 0.0, "fuel": 0.0, "risk": 0.0, "days_travelled": 0, "total_path": []}}

    ####TODO: Weak huirastic need a stronger one
    # def heuristic(self, current_place: str, destination: str) -> float:
    #     best_path = float("inf")  # initialize with infinity
    #
    #     # check if source and dest are directly connected
    #     for city in self.usa_map.edges_base:
    #         if (city["from"] == current_place and city["to"] == destination) or (
    #                 city["from"] == destination and city["to"] == current_place):
    #             best_path = min(best_path, city["distance"])
    #
    #     if best_path == float("inf"):  # save from divide by inf error
    #         return 0.0
    #
    #     return best_path / self.usa_map.base_mpg

    def search(self, current: str, destination: str) -> Optional[Dict[str, Any]]:
        """
        A* start algorithm
        :param current: current city
        :param destination: destination city
        :return: metadata JSON if when reached else empty
        """
        # reset
        self.meta_data = {
            "daily": defaultdict(lambda: {"path": [], "distance": 0.0, "fuel": 0.0, "risk": 0.0, "edges": []}),
            "total": {"distance": 0.0, "fuel": 0.0, "risk": 0.0, "days_travelled": 0, "total_path": []}}

        # priority q
        # h,g,current_city,days_taken, path
        open_pq: List[Tuple[float, float, str, int, List[str]]] = []
        starting_hur = 0.0  # initial h function
        heapq.heappush(open_pq, (starting_hur, 0.0, current, 0, [current]))  # push start city into pq

        best_route = {}  # Best route to take on the given day

        # Until empty
        while open_pq:
            # pop first element
            hur, g, current, day, path = heapq.heappop(open_pq)
            if current == destination:  # reached destination
                self.meta_data["total"]["total_path"] = path  # path taken to reach destination
                self.meta_data["total"]["days_travelled"] = day  # days taken to reach the destination
                self.populate_meta_data(path)  # generate the meta_data
                return {
                    "path": path,
                    "cost": g,
                    "days_travelled": day,
                    "meta_data": self.meta_data
                }

            if day >= self.max_days:  # not able to complete travel within given days
                continue

            key = (current, day)
            # if we have a better day to travel this route? skip today
            if key in best_route and g > best_route[key] + 1e-9:
                continue
            best_route[key] = g  # best route for the day to travel

            # Cities reachable within today
            reachable = self.usa_map.reachable_within_day_min_cost(current, day)
            #print(reachable)
            for dest, info in reachable.items():
                if dest == current:
                    continue

                trans_cost = info["cost"]  # cost taken to reach
                first_hop = info["edges"][0] if info["edges"] else (current, dest)  # Paths to be taken
                next_city = first_hop[1]  # immediate next city
                # penalize if the movement is opposite to the goal direction
                # direction_penalty = self.direction_penalty(current, next_city, destination)
                h = self.heuristic(current, next_city, destination)  # get the heuristic data
                # total cost is the cost to travel and the direction penalty
                # total_cost = trans_cost + direction_penalty
                # new accumulated cost
                new_g = g + trans_cost  # g function is added with cost to reach
                new_day = day + 1  # next day
                # h = self.heuristic(dest, destination)
                new_f = new_g + h  # f=g+h
                # include the multi hop path in final path
                new_path = path + info["path"][1:]  # skip in initial node, which is the current node
                # check for better day
                key2 = (dest, new_day)
                if key2 in best_route and new_g >= best_route[key2] - 1e-9:
                    continue
                heapq.heappush(open_pq, (new_f, new_g, dest, new_day, new_path))  # push the element

        return None  # if goal cannot be reached

    ##TODO: Better use of function
    # def direction_penalty(self, current, next_city, destination) -> float:
    #     # if no penalty
    #     if not self.use_direction_penalty:
    #         return 0.0
    #
    #     # Get the coordinates
    #     coordinate_curr = self.usa_map.cities[current].get("coord")
    #     coordinate_next = self.usa_map.cities[next_city].get("coord")
    #     coordinate_goal = self.usa_map.cities[destination].get("coord")
    #
    #     if not coordinate_curr or not coordinate_next or not coordinate_goal:
    #         return 0.0
    #
    #     vx = coordinate_goal[0] - coordinate_curr[0]
    #     vy = coordinate_goal[1] - coordinate_curr[1]
    #     ux = coordinate_next[0] - coordinate_curr[0]
    #     uy = coordinate_next[1] - coordinate_curr[1]
    #
    #     denom = math.hypot(vx, vy) * math.hypot(ux, uy)
    #     # correct/partially right direction no penalty
    #     if denom == 0:
    #         return 0.0
    #
    #     cos_theta = (vx * ux + vy * uy) / denom
    #     if cos_theta >= 0:
    #         return 0.0
    #     # moving opposite direction
    #     return (-cos_theta) * self.penalty_factor



        # def populates_meta_data(self, final_path):
        #     """
        #     Given final path this tries to reconstruct/backtracks the travel per day
        #     based on the travel constraints
        #     :param final_path: final path to travel all the cities
        #     """
        #     remaining_cities = list(final_path)
        #     current_day = 0  # start from 1st day
        #     current_city = remaining_cities[0]  # start city
        #     i = 1  # index of next city
        #
        #     # path covered or ran out of days
        #     while i < len(remaining_cities) and current_day < self.usa_map.days:
        #         reachable_cities = (self.usa_map.
        #                             reachable_within_day_min_cost(current_city,
        #                                                           current_day))  # cities reachable from the current city in current day
        #
        #         # store best possible route
        #         best_dest = None
        #         best_prefix_len = 0
        #         best_city_metadata = None
        #         # greedy select the max reachable dest
        #         for j in range(i, len(remaining_cities)):
        #             possible_dest = remaining_cities[j]  # possible destination to reach today
        #
        #             if possible_dest in reachable_cities:
        #                 city_metadata = reachable_cities[possible_dest]
        #                 prefix_nodes = city_metadata["path"]
        #                 # check if it is required city then
        #                 # or intermediate stop
        #                 if prefix_nodes == remaining_cities[i - 1:j + 1]:
        #                     if (j - i + 1) > best_prefix_len:
        #                         best_prefix_len = (j - i + 1)
        #                         best_dest = possible_dest
        #                         best_city_metadata = city_metadata
        #
        #         # TODO: Should I wait and check tomorrow?
        #         if best_dest is None:  # no best city possible, travel to next.
        #             next_city = remaining_cities[i]
        #             if next_city in reachable_cities:
        #                 best_prefix_len = 1
        #                 best_dest = next_city
        #                 best_city_metadata = reachable_cities[next_city]
        #             else:
        #                 break
        #
        #         # day wise meta data
        #         day_record = self.meta_data["daily"][current_day]
        #         day_record["path"] = best_city_metadata["path"]
        #         day_record["distance"] = best_city_metadata["distance"]
        #         day_record["fuel"] = 0.0
        #         day_record["risk"] = 0.0
        #         day_record["edges"] = []
        #
        #         # each route refer the map for fuel consumption, weather risk
        #         for (u, v) in best_city_metadata["edges"]:
        #             route_info = self.usa_map.get_edge_info(u, v, current_day)
        #             if route_info is None:  # fail-safe
        #                 continue
        #
        #             day_record["fuel"] += route_info["gallons"]
        #             day_record["risk"] += route_info["avg_weather"]
        #             day_record["edges"].append(
        #                 {"from": u, "to": v, "distance": route_info["distance"], "gallons": route_info["gallons"],
        #                  "avg_weather": route_info["avg_weather"], "weight": route_info["weight"]})
        #
        #             # add to total metadata as well
        #             self.meta_data["total"]["distance"] += route_info["distance"]
        #             self.meta_data["total"]["fuel"] += route_info["gallons"]
        #             self.meta_data["total"]["risk"] += route_info["avg_weather"]
        #
        #         # move next
        #         current_city = best_dest
        #         i = i + best_prefix_len
        #         current_day += 1
        #
        #     self.meta_data["total"]["days_travelled"] = current_day

    def populate_meta_data(self, final_path, max_wait_days=2):
        """
        Given final path this tries to reconstruct/backtracks the travel per day
        based on the travel constraints
        :param final_path: final path to travel all the cities
        """
        remaining_cities = list(final_path)
        current_day = 0
        current_city = remaining_cities[0]
        i = 1  # index of next city to travel
        # path covered or ran out of days
        while i < len(remaining_cities) and current_day < self.usa_map.days:
            best_travel_choice = None  #store best travel day/route

            #lookahead the numer of days to see if the cost improves,
            #possible of a pit stop
            for wait in range(max_wait_days + 1):
                #look ahead of path costs
                day_to_check = current_day + wait
                print(current_day)
                #cannot get passed the max days
                if day_to_check >= self.usa_map.days:
                    continue

                #get cities that can be reached today
                reachable = self.usa_map.reachable_within_day_min_cost(
                    current_city, day_to_check)

                #Move as many cities as possible today (greedy approach)
                for j in range(i, len(remaining_cities)):
                    possible_dest = remaining_cities[j] #possible destination
                    #if reachable, then travel
                    if possible_dest in reachable:
                        metadata = reachable[possible_dest]
                        prefix_nodes = metadata["path"]

                        #check if the route matches the towards the final path by A*
                        if prefix_nodes == remaining_cities[i - 1:j + 1]:
                            cost_today = metadata["cost"]

                            #Stay the day in the city
                            if (best_travel_choice is None) or (cost_today < best_travel_choice["cost"]):
                                #add a day record that you stayed
                                print(current_day)
                                day_record = self.meta_data["daily"][current_day]
                                day_record["path"] = [current_city]
                                day_record["distance"] = 0.0
                                day_record["fuel"] = 0.0
                                day_record["risk"] = 0.0
                                day_record["edges"] = []
                                best_travel_choice = {
                                    "dest": possible_dest,
                                    "prefix_len": j - i + 1,
                                    "metadata": metadata,
                                    "wait_days": wait,
                                    "cost": cost_today,
                                    "day": day_to_check
                                }

            if best_travel_choice is None:
                #if max days will reach, if you wait? forced to take the next best route
                next_city = remaining_cities[i]
                reachable = (self.usa_map.reachable_within_day_min_cost
                             (current_city, current_day))
                if next_city in reachable:
                    metadata = reachable[next_city]
                    best_travel_choice = {
                        "dest": next_city,
                        "prefix_len": 1,
                        "metadata": metadata,
                        "wait_days": 0,
                        "cost": metadata["cost"],
                        "day": current_day
                    }
                else:
                    #cannot travel
                    break

            #Record this day's travel metadata
            day_record = self.meta_data["daily"][best_travel_choice["day"]]
            day_record["path"] = best_travel_choice["metadata"]["path"]
            day_record["distance"] = best_travel_choice["metadata"]["distance"]
            day_record["fuel"] = 0.0
            day_record["risk"] = 0.0
            day_record["edges"] = []

            #get fuel,weather and mph data from the graph
            for (u, v) in best_travel_choice["metadata"]["edges"]:
                edge_info = self.usa_map.get_edge_info(u, v, best_travel_choice["day"])
                if edge_info is None:
                    continue
                day_record["fuel"] += edge_info["gallons"]
                #day_record["risk"] += edge_info["avg_weather"]
                day_record["edges"].append({
                    "from": u, "to": v, "distance": edge_info["distance"],
                    "gallons": edge_info["gallons"],
                    #"avg_weather": edge_info["avg_weather"],
                    "weight": edge_info["weight"]
                })

                self.meta_data["total"]["distance"] += edge_info["distance"]
                self.meta_data["total"]["fuel"] += edge_info["gallons"]
                #self.meta_data["total"]["risk"] += edge_info["avg_weather"]

            #increment to the next
            current_city = best_travel_choice["dest"]
            i += best_travel_choice["prefix_len"]
            current_day = best_travel_choice["day"] + 1 #day after travel

        self.meta_data["total"]["days_travelled"] = current_day

    def pairwise_comp(self, city_a: str, city_b: str):
        # Dynamic programming, memoization approach
        key = tuple((city_a, city_b))
        # if already exists
        if key in self.pair_cache:
            return self.pair_cache[key]

        result = self.search(city_a, city_b)  # A* search for the given pair
        if result is None:  # Cannot reach
            no_path = {
                "path": [],
                "cost": float("inf"),
                "days_travelled": None,
                "meta_data": None
            }

            self.pair_cache[key] = no_path
            return no_path

        self.pair_cache[key] = result
        return result

    def build_cost_matrix(self, cities):  # real_distance + weather risk matrix
        """
        Build a cost directory
        :param cities: cities needed to travel
        :return: cost matrix
        """
        costs = {} #hold cost of pairs
        #Loop over each pair of cities
        for i, city_a in enumerate(cities):
            for city_b in cities[i + 1:]:
                #Compute cost of A-B
                result_cost_a_b = self.pairwise_comp(city_a, city_b)
                cost = result_cost_a_b["cost"] if result_cost_a_b is not None else float('inf')
                costs[(city_a, city_b)] = cost
                #Note cost of B-A is not same as A-B
                result_cost_b_a = self.pairwise_comp(city_b, city_a)
                cost = result_cost_b_a["cost"] if result_cost_b_a is not None else float('inf')
                costs[(city_b, city_a)] = cost

        for city in cities: #cost of itself
            costs[(city, city)] = 0.0

        return costs


    # def improve_path(self, route, costs, max_iter=200):
    #     def route_cost(r):
    #         total_route_cost = 0.0
    #         for i in range(len(r) - 1):
    #             total_route_cost += costs.get((r[i], r[i + 1]), float('inf'))
    #         return total_route_cost
    #
    #     best = route[:]
    #     best_cost = route_cost(best)
    #     improved = True
    #     it = 0
    #
    #     while improved and it < max_iter:
    #         improved = False
    #         it += 1
    #         n = len(best)
    #         for i in range(1, n - 1):
    #             for j in range(i + 1, n - 1):
    #
    #                 new = best[:i] + best[i:j + 1][::-1] + best[j + 1:]
    #                 cost = route_cost(new)
    #                 if cost < best_cost:
    #                     best = new
    #                     best_cost = cost
    #                     improved = True
    #                     break
    #
    #             if improved:
    #                 break
    #
    #     return best

    def execute_multiplicity(self, city_list):
        trip = [] #smaller trips to reach from one reqd city to another reqd city
        total_distance = 0.0  # total distance travelled
        total_days = 0 #days took to travel
        total_fuel = 0.0 #total fuel
        #total_risk = 0.0
        current_day = 0  #current day
        final_path = []
        schedule = [] #daily itearnary

        for i in range(len(city_list) - 1):
            city_a = city_list[i]
            city_b = city_list[i + 1]

            result = self.pairwise_comp(city_a, city_b)
            if result is None or result["cost"] == float("inf"):  # cannot reach
                trip.append({"from": city_a, "to": city_b}) #, "ok": False
                continue

            trip.append({
                "from": city_a, "to": city_b, #"ok": True,
                "cost": result["cost"],
                "days_travelled": result["days_travelled"],
                "path": result["path"],
                "meta_data": result["meta_data"]
            })

            trip_metadata = result.get("meta_data")
            if trip_metadata:
                for day_index, day_rec in trip_metadata["daily"].items():
                    schedule.append({
                        "global_day": current_day + int(day_index),
                        "trip_from": city_a,
                        "trip_to": city_b,
                        "path": day_rec["path"],
                        "distance": day_rec["distance"],
                        "fuel": day_rec["fuel"],
                        #"risk": day_rec["risk"],
                        "edges": day_rec["edges"]
                    })
                    total_distance += day_rec["distance"]
                    total_fuel += day_rec["fuel"]
                    #total_risk += day_rec["risk"]
                    total_days += 1
                current_day += trip_metadata["total"]["days_travelled"]

            if result["path"]:
                if not final_path:
                    final_path.extend(result["path"])
                else:
                    final_path.extend(result["path"][1:])

        return {
            "ordered_route": city_list,
            "trip": trip,
            "total_distance": total_distance,
            "total_days": total_days,
            "total_fuel": total_fuel,
            "daily_route": schedule,
            "final_path": final_path
        }

    def trip(self, initial_city_list):
        # needs at least two cities to travel
        if len(initial_city_list) < 2:
            return "need least two cities to travel"

        city_list = list(dict.fromkeys(initial_city_list))  # remove duplicates if any

        # fail-safe
        for city in city_list:
            if city not in self.usa_map.cities:
                return f"city {city} not found in map"
        #Take a initial guess and jump start the A*
        costs = self.build_cost_matrix(city_list)  # Pairwise costs
        initial_route = build_initial_route(city_list, costs)  # initial greedy path
        improved_route = improve_path(initial_route, costs)  # optimize route

        aggregated = self.execute_multiplicity(improved_route)
        aggregated["initial_route"] = initial_route
        aggregated["final_route"] = improved_route
        aggregated["pairwise_costs"] = costs
        return aggregated

    def heuristic(self, current: str, next_city: str, destination: str) -> float:
        """
        method to the h function of to next city towards dest city, says how many gas will be needed
        It penalizes to move in the opposite direction of dest
        """

        # get latitude and longitude coordinates of current, dest and next city
        coordinates_current_city = self.coordinates[current]
        coordinates_next_city = self.coordinates[next_city]
        coordinates_destination_city = self.coordinates[destination]

        if coordinates_current_city and coordinates_destination_city:
            dx = coordinates_destination_city[0] - coordinates_current_city[0]
            dy = coordinates_destination_city[1] - coordinates_current_city[1]

            straight_dist = math.hypot(dx, dy)  # get distance between current and destination
            base_h = straight_dist / self.usa_map.base_mpg  # estimated fuel needed to reach goal
        else:
            base_h = 0.0

        # direction penalty disabled
        if not self.use_direction_penalty:
            return base_h

        # coordinates not found
        if not coordinates_current_city or not coordinates_next_city or not coordinates_destination_city:
            return base_h

        vx = coordinates_destination_city[0] - coordinates_current_city[0]
        vy = coordinates_destination_city[1] - coordinates_current_city[1]
        ux = coordinates_next_city[0] - coordinates_current_city[0]
        uy = coordinates_next_city[1] - coordinates_current_city[1]

        theta = math.hypot(vx, vy) * math.hypot(ux, uy)
        # reached
        if theta == 0:
            return base_h

        cos_theta = (vx * ux + vy * uy) / theta  # cos angle tells the direction

        # towards dest
        if cos_theta >= 0:
            return base_h

        # opposite direction
        penalty = (-cos_theta) * self.penalty_factor * (straight_dist / self.usa_map.base_mpg)

        return base_h + penalty  # add penalty
