
import heapq
from collections import defaultdict
from typing import List, Dict, Tuple, Any, Optional

BASE_MPG = 45.0
MAX_MILES_PER_DAY = 8 * 75  # 360 miles/day
MAX_DAYS = 5  # number of weather days available
PENALTY_FACTOR = 10.0  # used if direction penalty is enabled

class CityGraph:
    def __init__(self,
                 cities: Dict[str, Dict[str, Any]],
                 edges_base: List[Dict[str, Any]],
                 weather: Dict[str, List[str]],
                 weather_map: Dict[str, float],
                 base_mpg: float = BASE_MPG,
                 max_miles_per_day: float = MAX_MILES_PER_DAY,
                 clamp_tan=(-0.5, 0.5)):
        self.cities = cities
        self.edges_base = edges_base
        self.weather = weather
        self.weather_map = weather_map
        self.base_mpg = base_mpg
        self.max_miles_per_day = max_miles_per_day
        self.days = 5  # len(next(iter(weather.values())))
        self.clamp_tan = clamp_tan

        # Build adjacency list (undirected)
        self.adj = defaultdict(list)
        for e in edges_base:
            u, v, d = e["from"], e["to"], e["distance"]
            self.adj[u].append((v, d))
            self.adj[v].append((u, d))

        # Precompute daily edge info: list indexed by day, map edge_key -> info
        self.daily_edge_info: List[Dict[Tuple[str, str], Dict[str, float]]] = []
        self._build_daily_edge_info()

        # reachable cache: reachable[day][source] -> {dest: {cost, distance, path, edges}}
        self.reachable = [defaultdict(dict) for _ in range(self.days)]

    def _edge_key(self, a: str, b: str) -> tuple[str, ...]:
        return tuple(sorted((a, b)))

    def _build_daily_edge_info(self):
        # precompute per edge per day weight and gallons
        for day in range(self.days):
            info = {}
            for e in self.edges_base:
                a, b, dist = e["from"], e["to"], e["distance"]
                elev_a = self.cities[a]["elevation"]
                elev_b = self.cities[b]["elevation"]
                # convert elevation meters -> miles for tan(theta)
                sea_diff_miles = (elev_a - elev_b) / 1609.34
                tan_theta = sea_diff_miles / dist if dist != 0 else 0.0
                tan_theta = max(self.clamp_tan[0], min(self.clamp_tan[1], tan_theta))
                real_mpg = max(1.0, self.base_mpg * (1.0 + tan_theta))
                gallons = dist / real_mpg
                # weather average for day
                wa = self.weather_map.get(self.weather[a][day].lower(), 3.0)
                wb = self.weather_map.get(self.weather[b][day].lower(), 3.0)
                avg_w = (wa + wb) / 2.0
                weight = gallons + avg_w  # primary cost
                info[self._edge_key(a, b)] = {
                    "distance": dist,
                    "gallons": gallons,
                    "avg_weather": avg_w,
                    "weight": weight,
                    "mpg": real_mpg
                }
            self.daily_edge_info.append(info)

    def get_edge_info(self, a: str, b: str, day: int) -> Optional[Dict[str, float]]:
        return self.daily_edge_info[day].get(self._edge_key(a, b))

    #Follows Dynamic memoization
    def reachable_within_day_min_cost(self, source: str, day: int) -> Dict[str, Dict[str, Any]]:
        """
        All the cities reachable from this given using the minimum possible
        travel cost for the day
        cost is defined as fuel needed for travel + weather_risk
        :param source: current city
        :param day: today
        :return: list of possible reachable city
        """
        if self.reachable[day].get(source): #if already exists skip
            return self.reachable[day][source]

        max_allowed_distance = self.max_miles_per_day

        # PQ defines the cost
        pq: List[Tuple[float, float, str, List[str], List[Tuple[str, str]]]] = []
        heapq.heappush(pq, (0.0, 0.0, source, [source], []))
        best_cost = {}  #lowest cost entries for each city
        result = {} #reachable city

        #dijastra loop
        while pq:
            #pop pq
            cost_so_far, dist_so_far, node, path_nodes, path_edges = heapq.heappop(pq)
            # If we have cheaper already
            if node in best_cost and cost_so_far > best_cost[node] + 1e-9:
                continue
            #Mark the city as reachable
            result[node] = {"cost": cost_so_far, "distance": dist_so_far, "path": list(path_nodes),
                            "edges": list(path_edges)}
            best_cost[node] = cost_so_far

            #Explore the neighbours
            for neighbour_city, edge_distance in self.adj.get(node, []):
                #distance if decided to this city
                new_dist = dist_so_far + edge_distance
                #if not within milage skip it
                if new_dist > max_allowed_distance + 1e-9:
                    continue
                #get avg weather and fuel needed for today to travel the route
                edge_info = self.get_edge_info(node, neighbour_city, day)
                if edge_info is None: #fail-safe
                    continue
                #Cost if we travel this route
                new_cost = cost_so_far + edge_info["weight"]

                #build the route
                new_path_nodes = path_nodes + [neighbour_city]
                new_path_edges = path_edges + [(node, neighbour_city)]
                # Push to pq
                if neighbour_city not in best_cost or new_cost + 1e-9 < best_cost.get(neighbour_city, float("inf")):
                    heapq.heappush(pq, (new_cost, new_dist, neighbour_city, new_path_nodes, new_path_edges))

        #memoize the results
        self.reachable[day][source] = result

        return result

    # def export_daily_graphs(self, prefix="graph_day"):
    #     import csv
    #     for day, info in enumerate(self.daily_edge_info):
    #         fname = f"{prefix}_{day + 1}.csv"
    #         with open(fname, "w", newline="") as f:
    #             writer = csv.writer(f)
    #             writer.writerow(["from", "to", "distance", "mpg", "gallons", "avg_weather", "weight"])
    #             for (a, b), v in info.items():
    #                 writer.writerow([a, b, v["distance"], v["mpg"], v["gallons"], v["avg_weather"], v["weight"]])
    #         print("Wrote", fname)
