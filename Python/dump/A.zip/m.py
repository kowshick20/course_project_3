import csv
import random

from AStar import Astar
from CityGraph import CityGraph
from map import plot_route_folium

BASE_MPG = 45.0
MAX_MILES_PER_DAY = 8 * 75  # 600 miles/day
MAX_DAYS = 5  # number of weather days available
PENALTY_FACTOR = 10.0  # used if direction penalty is enabled

cities_list = [
    "Portland",
    "Manchester",
    "Burlington",
    "Boston",
    "New York City",
    "Albany",
    "Buffalo",
    "Providence",
    "Hartford",
    "Philadelphia",
    "Pittsburgh",
    "Newark",
    "Wilmington",
    "Baltimore",
    "Charleston",
    "Columbus",
    "Cleveland",
    "Richmond",
    "Charlotte",
    "Raleigh",
    "Louisville",
    "Nashville",
    "Memphis",
    "Columbia",
    "Atlanta",
    "Jacksonville",
    "Miami",
    "Orlando",
    "Detroit",
    "Indianapolis"
]


# city_coords = {
#     "Jacksonville": (30.3322, -81.6557),
#     "Miami": (25.7617, -80.1918),
#     "Orlando": (28.5383, -81.3792),
#     "Detroit": (42.3314, -83.0458),
#     "Indianapolis": (39.7684, -86.1581),
# }


# cities = {
#     "A": {"elevation": 10},
#     "B": {"elevation": 50},
#     "C": {"elevation": 30},
#     "D": {"elevation": 20},
#     "E": {"elevation": 5},
#     "F": {"elevation": 80},
#     "G": {"elevation": 60},
#     "H": {"elevation": 25},
#     "I": {"elevation": 15},
#     "J": {"elevation": 100},
#     "K": {"elevation": 90},
#     "L": {"elevation": 40},
#     "M": {"elevation": 12},
#     "N": {"elevation": 5},
#     "O": {"elevation": 70}
# }
#
# edges_base = [
#     {"from": "A", "to": "B", "distance": 100},
#     {"from": "A", "to": "C", "distance": 140},
#     {"from": "A", "to": "J", "distance": 450},
#     {"from": "B", "to": "C", "distance": 60},
#     {"from": "B", "to": "D", "distance": 90},
#     {"from": "B", "to": "F", "distance": 110},
#     {"from": "C", "to": "E", "distance": 1080},
#     {"from": "C", "to": "G", "distance": 130},
#     {"from": "C", "to": "J", "distance": 300},
#     {"from": "D", "to": "F", "distance": 70},
#     {"from": "D", "to": "H", "distance": 95},
#     {"from": "F", "to": "G", "distance": 55},
#     {"from": "F", "to": "J", "distance": 220},
#     {"from": "G", "to": "H", "distance": 80},
#     {"from": "G", "to": "L", "distance": 140},
#     {"from": "H", "to": "M", "distance": 45},
#     {"from": "L", "to": "M", "distance": 100},
#     {"from": "L", "to": "O", "distance": 160},
#     {"from": "M", "to": "N", "distance": 60},
#     {"from": "N", "to": "E", "distance": 70},
#     {"from": "J", "to": "K", "distance": 75},
#     {"from": "K", "to": "I", "distance": 65},
#     {"from": "O", "to": "K", "distance": 150}
# ]


# weather = {
#     "A": ["snow", "sunny", "sunny", "sunny", "rain"],
#     "B": ["rain", "sunny", "rain", "rain", "sunny"],
#     "C": ["sunny", "rain", "sunny", "sunny", "sunny"],
#     "D": ["sunny", "sunny", "sunny", "rain", "sunny"],
#     "E": ["rain", "sunny", "sunny", "sunny", "sunny"],
#     "F": ["snow", "rain", "sunny", "sunny", "sunny"],
#     "G": ["sunny", "snow", "sunny", "rain", "rain"],
#     "H": ["sunny", "sunny", "sunny", "sunny", "sunny"],
#     "I": ["rain", "rain", "rain", "sunny", "sunny"],
#     "J": ["snow", "snow", "sunny", "sunny", "sunny"],
#     "K": ["sunny", "sunny", "sunny", "rain", "snow"],
#     "L": ["rain", "sunny", "sunny", "sunny", "rain"],
#     "M": ["sunny", "sunny", "sunny", "rain", "sunny"],
#     "N": ["sunny", "sunny", "sunny", "rain", "sunny"],
#     "O": ["sunny", "sunny", "snow", "snow", "rain"]
# }
#
# weather_risk_map = {"sunny": 1, "rain": 5, "snow": 10}


def load_city_graph_from_csv(csv_path):
    cities = {}
    edges_base = []
    coordinates = {}
    # Fixed weather map
    weather_risk_map = {"sunny": 1, "rain": 5, "snow": 10}

    # Weather types to pick from
    weather_types = ["sunny", "rain", "snow"]

    with open(csv_path, mode="r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)

        for row in reader:
            # Extract city names
            from_city = row["from_city"]
            to_city = row["to_city"]

            # Extract fields
            distance = float(row["real_distance_miles"])
            elevation_from = int(row["from_elevation_ft"])
            elevation_to = int(row["to_elevation_ft"])
            latitude_1 = float(row["from_lat"])
            longitude_1 = float(row["from_lon"])
            latitude_2 = float(row["to_lat"])
            longitude_2 = float(row["to_lon"])

            # Build cities dict
            if from_city not in cities:
                cities[from_city] = {"elevation": elevation_from}
                coordinates[from_city] = (latitude_1, longitude_1)

            if to_city not in cities:
                cities[to_city] = {"elevation": elevation_to}
                coordinates[to_city] = (latitude_2, longitude_2)


            # Build edges_base entry
            edges_base.append({
                "from": from_city,
                "to": to_city,
                "distance": distance,
                # you CAN include these if your A* uses them:
                "mpg": float(row["mpg"]),
                "gallons": float(row["gallons_needed"]),
                "risk": float(row["avg_risk_factor"])
            })

    # Create a stub 5-day weather forecast for each city
    weather = {
        city: [random.choice(weather_types) for _ in range(5)]
        for city in cities
    }

    return cities, edges_base, weather, weather_risk_map, coordinates


# ----------------------------
# AStarPlanner class with metadata
# ----------------------------
# class AStarPlanner:
#     def __init__(self, graph: CityGraph, max_days: int = 5,
#                  penalty_factor: float = 10, use_direction_penalty: bool = True):
#         self.graph = graph
#         self.max_days = min(max_days, graph.days)
#         self.penalty_factor = penalty_factor
#         self.use_direction_penalty = use_direction_penalty
#
#         # metadata
#         self.metadata = {
#             "daily": defaultdict(lambda: {"path": [], "distance": 0.0, "fuel": 0.0, "risk": 0.0, "edges": []}),
#             "total": {"distance": 0.0, "fuel": 0.0, "risk": 0.0, "days_used": 0, "full_path": []}
#         }
#
#     def _direction_penalty(self, curr: str, next_: str, goal: str) -> float:
#         if not self.use_direction_penalty:
#             return 0.0
#         coord_curr = self.graph.cities[curr].get("coord")
#         coord_next = self.graph.cities[next_].get("coord")
#         coord_goal = self.graph.cities[goal].get("coord")
#         if not coord_curr or not coord_next or not coord_goal:
#             return 0.0
#         vx = coord_goal[0] - coord_curr[0]
#         vy = coord_goal[1] - coord_curr[1]
#         ux = coord_next[0] - coord_curr[0]
#         uy = coord_next[1] - coord_curr[1]
#         denom = math.hypot(vx, vy) * math.hypot(ux, uy)
#         if denom == 0:
#             return 0.0
#         cos_theta = (vx * ux + vy * uy) / denom
#         # if cos_theta < 0 -> moving away; penalty proportional to -cos_theta
#         if cos_theta >= 0:
#             return 0.0
#         return (-cos_theta) * self.penalty_factor
#
#     def heuristic(self, node: str, goal: str) -> float:
#         # admissible: minimum remaining fuel cost estimated by single-edge distance if exists / base_mpg
#         best = float("inf")
#         for e in self.graph.edges_base:
#             if (e["from"] == node and e["to"] == goal) or (e["from"] == goal and e["to"] == node):
#                 best = min(best, e["distance"])
#         if best == float("inf"):
#             # weak but admissible: 0
#             return 0.0
#         return best / self.graph.base_mpg
#
#     def search(self, start: str, goal: str) -> Optional[Dict[str, Any]]:
#         # reset metadata
#         self.metadata = {
#             "daily": defaultdict(lambda: {"path": [], "distance": 0.0, "fuel": 0.0, "risk": 0.0, "edges": []}),
#             "total": {"distance": 0.0, "fuel": 0.0, "risk": 0.0, "days_used": 0, "full_path": []}
#         }
#
#         # Priority queue items: (f, g, node, day, full_path)
#         open_pq: List[Tuple[float, float, str, int, List[str]]] = []
#         start_h = self.heuristic(start, goal)
#         heapq.heappush(open_pq, (start_h, 0.0, start, 0, [start]))
#         best_g = {}  # (node, day) -> best g
#
#         while open_pq:
#             f, g, node, day, path = heapq.heappop(open_pq)
#
#             # If we've reached goal
#             if node == goal:
#                 # Build metadata from path and day-layer transitions by recomputing per-day moves
#                 # We'll reconstruct day-by-day moves by greedily recomputing reachable sets used by the search.
#                 self.metadata["total"]["full_path"] = path
#                 self.metadata["total"]["days_used"] = day
#                 # compute per-day breakdown by simulating the chosen path: at day i use minimal-cost path from current to next
#                 self._populate_metadata_from_path(path, goal)
#                 return {
#                     "path": path,
#                     "cost": g,
#                     "day_reached": day,
#                     "metadata": self.metadata
#                 }
#
#             if day >= self.max_days:
#                 continue
#
#             key = (node, day)
#             if key in best_g and g > best_g[key] + 1e-9:
#                 continue
#             best_g[key] = g
#
#             # get reachable destinations within this day
#             reachable = self.graph.reachable_within_day_min_cost(node, day)
#             for dest, info in reachable.items():
#                 if dest == node:
#                     continue
#                 trans_cost = info["cost"]
#                 # add direction penalty (dynamic, based on goal)
#                 # direction penalty should be applied per-edge; for multi-edge within-day we approximate by applying
#                 # penalty to the first edge from node -> next_in_path
#                 first_hop = info["edges"][0] if info["edges"] else (node, dest)
#                 nxt = first_hop[1]
#                 dir_pen = self._direction_penalty(node, nxt, goal)
#                 total_trans_cost = trans_cost + dir_pen
#                 new_g = g + total_trans_cost
#                 new_day = day + 1
#                 h = self.heuristic(dest, goal)
#                 new_f = new_g + h
#                 new_path = path + info["path"][1:]  # append the multi-hop path (exclude duplicate node)
#                 key2 = (dest, new_day)
#                 if key2 in best_g and new_g >= best_g[key2] - 1e-9:
#                     continue
#                 heapq.heappush(open_pq, (new_f, new_g, dest, new_day, new_path))
#
#         return None
#
#     def _populate_metadata_from_path(self, full_path: List[str], goal: str):
#         """
#         Walk the full path (sequence of nodes) and assign segments to days by re-creating which multi-hop
#         move was used each day according to reachable computations. This is best-effort reconstruction.
#         """
#         # Start at day 0, position at first node, then repeatedly find the farthest prefix of the remaining path
#         # that is reachable within day's miles with minimal cost (as computed earlier).
#         remaining_nodes = list(full_path)
#         current_day = 0
#         current_node = remaining_nodes[0]
#         i = 1
#         while i < len(remaining_nodes) and current_day < self.graph.days:
#             # find the next node that matches one of the reachable destinations from current_node at this day
#             reachable = (self.graph.
#                          reachable_within_day_min_cost(current_node, current_day))
#             # Try to find the longest prefix reachable
#             best_dest = None
#             best_prefix_len = 0
#             best_info = None
#             # Build candidate prefixes
#             for j in range(i, len(remaining_nodes)):
#                 candidate_dest = remaining_nodes[j]
#                 if candidate_dest in reachable:
#                     # verify that path matches the prefix
#                     info = reachable[candidate_dest]
#                     prefix_nodes = info["path"]
#                     # info["path"] is the exact path from current_node to candidate_dest; check if matches remaining_nodes[i:j+1]
#                     if prefix_nodes == remaining_nodes[i-1:j+1]:
#                         # prefer farthest (largest j)
#                         if (j - i + 1) > best_prefix_len:
#                             best_prefix_len = (j - i + 1)
#                             best_dest = candidate_dest
#                             best_info = info
#             if best_dest is None:
#                 # No matching reachable prefix (this can happen due to tie-breaking); fallback: pick immediate neighbor if reachable
#                 # immediate neighbor:
#                 next_node = remaining_nodes[i]
#                 if next_node in reachable:
#                     best_dest = next_node
#                     best_info = reachable[next_node]
#                     best_prefix_len = 1
#                 else:
#                     # can't reconstruct further; stop metadata fill
#                     break
#
#             # record metadata for this day
#             day_record = self.metadata["daily"][current_day]
#             day_record["path"] = best_info["path"]
#             day_record["distance"] = best_info["distance"]
#             day_record["fuel"] = 0.0
#             day_record["risk"] = 0.0
#             day_record["edges"] = []
#             # compute per-edge metadata using daily_edge_info
#             for (u, v) in best_info["edges"]:
#                 einfo = self.graph.get_edge_info(u, v, current_day)
#                 if einfo is None:
#                     continue
#                 day_record["fuel"] += einfo["gallons"]
#                 day_record["risk"] += einfo["avg_weather"]
#                 day_record["edges"].append({"from": u, "to": v, "distance": einfo["distance"], "gallons": einfo["gallons"],
#                                             "avg_weather": einfo["avg_weather"], "weight": einfo["weight"]})
#                 # accumulate
#                 self.metadata["total"]["distance"] += einfo["distance"]
#                 self.metadata["total"]["fuel"] += einfo["gallons"]
#                 self.metadata["total"]["risk"] += einfo["avg_weather"]
#
#             current_node = best_dest
#             i = i + best_prefix_len
#             current_day += 1
#
#         self.metadata["total"]["days_used"] = current_day
#
#
#     def format_metadata_report(metadata: dict) -> str:
#         """
#         Converts raw metadata into a human-readable multi-line report.
#         """
#         lines = []
#         total = metadata.get("total", {})
#         daily = metadata.get("daily", {})
#
#         # Header
#         lines.append("=" * 60)
#         lines.append("            🚗 TRAVEL metadata REPORT")
#         lines.append("=" * 60)
#
#         # Full Path
#         full_path = total.get("full_path", [])
#         if full_path:
#             lines.append("\n🛣️  Route Taken:")
#             lines.append("   → " + " → ".join(full_path))
#
#         # Totals
#         lines.append("\n📊 TOTAL SUMMARY")
#         lines.append(f"   • Total Distance: {total.get('distance', 0):.2f} miles")
#         lines.append(f"   • Total Fuel Used: {total.get('fuel', 0):.2f} gallons")
#         lines.append(f"   • Total Risk Score: {total.get('risk', 0):.2f}")
#         lines.append(f"   • Total Days Used: {total.get('days_used', 0)}")
#
#         # Per-Day
#         lines.append("\n📅 DAILY BREAKDOWN")
#         for day in sorted(daily.keys()):
#             d = daily[day]
#             lines.append(f"\n   Day {day + 1}:")
#             lines.append(f"      - Cities: {' → '.join(d.get('path', []))}")
#             lines.append(f"      - Distance: {d.get('distance', 0):.2f} miles")
#             lines.append(f"      - Fuel: {d.get('fuel', 0):.2f} gallons")
#             lines.append(f"      - Risk: {d.get('risk', 0):.2f}")
#             if d.get("edges"):
#                 lines.append(f"      - Road Segments:")
#                 for u, v in d["edges"]:
#                     lines.append(f"           • {u} → {v}")
#
#         lines.append("\n" + "=" * 60)
#         return "\n".join(lines)

def print_full_metadata(report: dict, coordinates: {}):
    # Final route
    print(report)
    route = report.get("final_route", [])
    print("\nFinal Route:")
    print("   " + " → ".join(route))
    plot_route_folium(route, report, coordinates)
    # Overall summary
    print("\nSummary:")
    print(f"   • Total Distance: {report.get('total_distance', 0):.2f} miles")
    print(f"   • Total Fuel: {report.get('total_fuel', 0):.2f} gallons")
    print(f"   • Total Trips: {len(report.get('trip', []))}")

    # Per-leg breakdown
    print("\nTrip Details:")
    for idx, trip in enumerate(report.get("trip", []), start=1):
        print(f"\nTrip {idx}: {trip['from']} → {trip['to']}")
        #print(f"   Status: {'OK' if leg.get('ok') else 'Failed'}")
        print(f"   Cost: {trip.get('cost', 0):.2f}")
        print(f"   Days: {trip.get('days_travelled', 0)}")
        print(f"   Path: {' → '.join(trip.get('path', []))}")

        metadata = trip.get("meta_data", {})
        daily_info = metadata.get("daily", {})

        for day_idx in sorted(daily_info):
            day = daily_info[day_idx]
            print(f"      Day {day_idx + 1}:")
            print(f"         Cities: {' → '.join(day.get('path', []))}")
            print(f"         Distance: {day.get('distance', 0):.2f} mi")
            print(f"         Fuel: {day.get('fuel', 0):.2f} gal")
            # print(f"         Risk: {day.get('risk', 0):.2f}")

            print("         Edges:")
            for edge in day.get("edges", []):
                print(f"            {edge['from']} → {edge['to']} "
                      f"({edge['distance']:.2f} mi, "
                      f"{edge['gallons']:.2f} gal, "
                      # f"risk={edge['avg_weather']:.2f}, "
                      f"weight={edge['weight']:.2f})")

    # Global day-by-day schedule
    print("\nDaily Schedule:")
    for entry in report.get("daily_route", []):
        print(f"\nDay {entry['global_day']}: {entry['trip_from']} → {entry['trip_to']}")
        print(f"   Path: {' → '.join(entry['path'])}")
        print(f"   Distance: {entry['distance']:.2f} mi")
        print(f"   Fuel: {entry['fuel']:.2f} gal")
        # print(f"   Risk: {entry['risk']:.2f}")
        print("   Edges:")
        for edge in entry.get("edges", []):
            print(f"      {edge['from']} → {edge['to']} "
                  f"({edge['distance']:.2f} mi, "
                  f"{edge['gallons']:.2f} gal, "
                  # f"risk={edge['avg_weather']:.2f}, "
                  f"weight={edge['weight']:.2f})")


def pick_random_cities(n):
    shuffled = cities_list[:]  # copy
    random.shuffle(shuffled)  # scramble order
    return shuffled[:n]  # return N random cities


if __name__ == "__main__":
    cities, edges_base, weather, weather_risk_map, coordinates = load_city_graph_from_csv("travel_data.csv")
    #print(coordinates)
    cg = CityGraph(cities=cities, edges_base=edges_base, weather=weather,
                   weather_map=weather_risk_map, base_mpg=BASE_MPG,
                   max_miles_per_day=MAX_MILES_PER_DAY)

    # optional: write per-day CSVs
    #cg.export_daily_graphs(prefix="example_graph_day")
    # planner = AStarPlanner(graph=cg, max_days=5, penalty_factor=PENALTY_FACTOR, use_direction_penalty=True)
    # mcp = MultiCityPlanner(city_graph=cg, astar_planner=planner, verbose=True)
    multi_city = Astar(graph=cg,coordinates=coordinates, max_days=5, penalty_factor=PENALTY_FACTOR, use_direction_penalty=True)
    # unordered = ["A", "C", "E", "B", "D"]  # user-supplied unordered list
    N = 10
    unordered = pick_random_cities(N)
    #print(N)
    #print(unordered)
    #     print(result)
    #     unordered = [
    #     "Jacksonville",
    #     "Miami",
    #     "Orlando",
    #     "Detroit",
    #     "Indianapolis"
    # ]
    # result = mcp.plan_unordered_trip(unordered)
    result = multi_city.trip(unordered)
    # print(result)

    print(print_full_metadata(result, coordinates))

    # res = planner.search("A", "E")
    # print("\nSearch result:")
    # print(res)
    #
    # # Print metadata nicely
    # print("\nmetadata summary:")
    # print("Total distance:", planner.metadata["total"]["distance"])
    # print("Total fuel:", planner.metadata["total"]["fuel"])
    # print("Total risk:", planner.metadata["total"]["risk"])
    # print("Days used:", planner.metadata["total"]["days_used"])
    # for d in range(planner.metadata["total"]["days_used"]):
    #     rec = planner.metadata["daily"][d]
    #     print(f"Day {d+1}: path={rec['path']}, dist={rec['distance']}, fuel={rec['fuel']}, risk={rec['risk']}")
